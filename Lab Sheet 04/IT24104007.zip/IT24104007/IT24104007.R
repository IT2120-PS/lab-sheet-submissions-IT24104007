setwd("C:\\Users\\it24104007\\Desktop\\IT24104007\\Lab 04-20250822")
data <- read.csv("Exercise.txt", header = TRUE)
str(data)
names(data)

boxplot(data$Sales,main="Box plot of sales:",col="yellow")

summary(data$Advertising)
IQR(data$Advertising)

find_outliers <- function(x) {
  Q1 <- quantile(x, 0.25)
  Q3 <- quantile(x, 0.75)
  IQR_val <- IQR(x)
  
  lower <- Q1 - 1.5 * IQR_val
  upper <- Q3 + 1.5 * IQR_val
  Outliers <- x[x < lower | x > upper]
  return(Outliers)
}

find_outliers(data$Years)

